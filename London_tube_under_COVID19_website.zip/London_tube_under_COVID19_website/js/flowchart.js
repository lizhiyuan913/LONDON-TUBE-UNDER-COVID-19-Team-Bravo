// A point click event that uses the Renderer to draw a label next to the point
// On subsequent clicks, move the existing label instead of creating a new one.
//$('#container').highcharts(json);
function getINflow(stations_ID,day) {
  var url = "http://dev.spatialdatacapture.org:8894/data/IN/"+stations_ID+"/"+day;
  $.getJSON( url , function( data ) {
        console.log(data[0]["lat"]);
        var flowdata1 = data[0][5];
        var flowdata2 = data[0][6];
        var flowdata3 = data[0][7];
        var flowdata4 = data[0][8];
        var flowdata5 = data[0][9];
        var flowdata6 = data[0][10];
        var flowdata7 = data[0][11];
        var flowdata8 = data[0][12];
        var flowdata9 = data[0][13];
        var flowdata10 = data[0][14];
        var flowdata11 = data[0][15];
        var flowdata12 = data[0][16];
        var flowdata13 = data[0][17];
        var flowdata14 = data[0][18];
        var flowdata15 = data[0][19];
        var flowdata16 = data[0][20];
        var flowdata17 = data[0][21];
        var flowdata18 = data[0][22];
        var flowdata19 = data[0][23];
        var flowdata20 = data[0][24];
        var flowdata21 = data[0][1];
        var flowdata22 = data[0][2];
        var flowdata23 = data[0][3];
        var flowdata24 = data[0][4];

        var flowdata1_1 = data[1][5];
        var flowdata2_1 = data[1][6];
        var flowdata3_1 = data[1][7];
        var flowdata4_1 = data[1][8];
        var flowdata5_1 = data[1][9];
        var flowdata6_1 = data[1][10];
        var flowdata7_1 = data[1][11];
        var flowdata8_1 = data[1][12];
        var flowdata9_1 = data[1][13];
        var flowdata10_1 = data[1][14];
        var flowdata11_1 = data[1][15];
        var flowdata12_1 = data[1][16];
        var flowdata13_1 = data[1][17];
        var flowdata14_1 = data[1][18];
        var flowdata15_1 = data[1][19];
        var flowdata16_1 = data[1][20];
        var flowdata17_1 = data[1][21];
        var flowdata18_1 = data[1][22];
        var flowdata19_1 = data[1][23];
        var flowdata20_1 = data[1][24];
        var flowdata21_1 = data[1][1];
        var flowdata22_1 = data[1][2];
        var flowdata23_1 = data[1][3];
        var flowdata24_1 = data[1][4];
        console.log(flowdata1);
        console.log("Chart1 Start!");

    Highcharts.chart('container',{
      chart: {
        height: 180,
	     width: 290,
	     backgroundColor: false,
      },
  

      title: {
          text: null
      },

      xAxis: {
        categories: ['05:00','06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00','24:00','01:00','02:00','03:00','04:00'],
        tickInterval:  23,
        labels: {
          align: 'right',
          x: 17,
          y: 16
        }
      },

      yAxis: [{ // left y axis
        title: {
          text: ' ',
      },
      labels: {
        align: 'left',
	       x: -20,
	       y: 13,
         format: '{value:.,0f}'
      },
      showFirstLabel: false
    }],

    legend: {
      align: 'right',
	   y: 0,
      verticalAlign: 'top',
      borderWidth: 0,
    },

    tooltip: {
      shared: true,
      crosshairs: true
    },

    plotOptions: {
      series: {
        cursor: 'pointer',
        className: 'popup-on-click',
        marker: {
          lineWidth: 1
        }
      }
    },

    series: [{
     name: '2019',
	   data:[flowdata1, flowdata2, flowdata3, flowdata4, flowdata5, flowdata6, flowdata7, flowdata8,
      flowdata9, flowdata10, flowdata11, flowdata12, flowdata13, flowdata14, flowdata15, flowdata16,
       flowdata17, flowdata18, flowdata19, flowdata20, flowdata21, flowdata22, flowdata23, flowdata24],
	   lineWidth: 2,
     marker: {
      radius: 3
     },
	   color: '#999999',
    },
    {
      name: '2020',
	    data:[flowdata1_1, flowdata2_1, flowdata3_1, flowdata4_1, flowdata5_1, flowdata6_1, flowdata7_1, flowdata8_1,
      flowdata9_1, flowdata10_1, flowdata11_1, flowdata12_1, flowdata13_1, flowdata14_1, flowdata15_1, flowdata16_1,
       flowdata17_1, flowdata18_1, flowdata19_1, flowdata20_1, flowdata21_1, flowdata22_1, flowdata23_1, flowdata24_1],
      lineWidth: 2,
	    color: '#a50202',}]

    });
  });
  console.log("Chart1 Done!");
};

function getOUTflow(stations_ID,day) {
  var url = "http://dev.spatialdatacapture.org:8894/data/OUT/"+stations_ID+"/"+day;
  $.getJSON( url , function( data ) {
        console.log(data[0]["lat"]);
        var flowdata1 = data[0][5];
        var flowdata2 = data[0][6];
        var flowdata3 = data[0][7];
        var flowdata4 = data[0][8];
        var flowdata5 = data[0][9];
        var flowdata6 = data[0][10];
        var flowdata7 = data[0][11];
        var flowdata8 = data[0][12];
        var flowdata9 = data[0][13];
        var flowdata10 = data[0][14];
        var flowdata11 = data[0][15];
        var flowdata12 = data[0][16];
        var flowdata13 = data[0][17];
        var flowdata14 = data[0][18];
        var flowdata15 = data[0][19];
        var flowdata16 = data[0][20];
        var flowdata17 = data[0][21];
        var flowdata18 = data[0][22];
        var flowdata19 = data[0][23];
        var flowdata20 = data[0][24];
        var flowdata21 = data[0][1];
        var flowdata22 = data[0][2];
        var flowdata23 = data[0][3];
        var flowdata24 = data[0][4];

        var flowdata1_1 = data[1][5];
        var flowdata2_1 = data[1][6];
        var flowdata3_1 = data[1][7];
        var flowdata4_1 = data[1][8];
        var flowdata5_1 = data[1][9];
        var flowdata6_1 = data[1][10];
        var flowdata7_1 = data[1][11];
        var flowdata8_1 = data[1][12];
        var flowdata9_1 = data[1][13];
        var flowdata10_1 = data[1][14];
        var flowdata11_1 = data[1][15];
        var flowdata12_1 = data[1][16];
        var flowdata13_1 = data[1][17];
        var flowdata14_1 = data[1][18];
        var flowdata15_1 = data[1][19];
        var flowdata16_1 = data[1][20];
        var flowdata17_1 = data[1][21];
        var flowdata18_1 = data[1][22];
        var flowdata19_1 = data[1][23];
        var flowdata20_1 = data[1][24];
        var flowdata21_1 = data[1][1];
        var flowdata22_1 = data[1][2];
        var flowdata23_1 = data[1][3];
        var flowdata24_1 = data[1][4];
        console.log(flowdata1);
        console.log("Chart2 Start!");

    Highcharts.chart('container2',{
      chart: {
        height: 180,
       width: 290,
       backgroundColor: false,
      },
  

      title: {
          text: null
      },

      xAxis: {
        categories: ['05:00','06:00','07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00','24:00','01:00','02:00','03:00','04:00'],
        tickInterval:  23,
        labels: {
          align: 'right',
          x: 17,
          y: 16
        }
      },

      yAxis: [{ // left y axis
        title: {
          text: ' ',
      },
      labels: {
        align: 'left',
         x: -20,
         y: 13,
         format: '{value:.,0f}'
      },
      showFirstLabel: false
    }],

    legend: {
      align: 'right',
     y: 0,
      verticalAlign: 'top',
      borderWidth: 0,
    },

    tooltip: {
      shared: true,
      crosshairs: true
    },

    plotOptions: {
      series: {
        cursor: 'pointer',
        className: 'popup-on-click',
        marker: {
          lineWidth: 1
        }
      }
    },

    series: [{
     name: '2019',
     data:[flowdata1, flowdata2, flowdata3, flowdata4, flowdata5, flowdata6, flowdata7, flowdata8,
      flowdata9, flowdata10, flowdata11, flowdata12, flowdata13, flowdata14, flowdata15, flowdata16,
       flowdata17, flowdata18, flowdata19, flowdata20, flowdata21, flowdata22, flowdata23, flowdata24],
     lineWidth: 2,
     marker: {
      radius: 3
     },
     color: '#999999',
    },
    {
      name: '2020',
      data:[flowdata1_1, flowdata2_1, flowdata3_1, flowdata4_1, flowdata5_1, flowdata6_1, flowdata7_1, flowdata8_1,
      flowdata9_1, flowdata10_1, flowdata11_1, flowdata12_1, flowdata13_1, flowdata14_1, flowdata15_1, flowdata16_1,
       flowdata17_1, flowdata18_1, flowdata19_1, flowdata20_1, flowdata21_1, flowdata22_1, flowdata23_1, flowdata24_1],
      lineWidth: 2,
      color: '#a50202',}]

    });
  });
  console.log("Chart2 Done!");
};

