	var map;
	var markerArray = [];
	var dataArray = [];
	var selectedstation;
	var selectedtime = '0';
	var selectedmarker;
	var iconstyle;
	var z;
	var infowindow = new google.maps.InfoWindow({maxWidth: 300});
	var transitLayer = new google.maps.TransitLayer();
	var port = 8894;

	document.getElementById("station-details").style.visibility="hidden";
	document.getElementById("help2text").style.visibility="hidden";
	document.getElementById("help3text").style.visibility="hidden";
	document.getElementById("help4text").style.visibility="hidden";
	document.getElementById("help5text").style.visibility="hidden";
	document.getElementById("help6text").style.visibility="hidden";


	$(document).ready(function() {

		// ---------------- ANOTHER WAY -------------------------------------------------------

		//  This click event is a shortcut I can use to embed the data values in the attributes of the link
		//   Rather than having 10 individual click events I only need 1

		$("#btn-confirm").click( function(event){
			event.preventDefault();
			//Clear Markers and remove event listener for map drag
			setAllMap(null);
			google.maps.event.clearListeners(map);
			var yearlist_value=document.getElementById('yearselect').value;
			var daylist_value=document.getElementById('dayselect').options[document.getElementById('dayselect').selectedIndex].value;
			var dirlist_value=document.getElementById('dirselect').options[document.getElementById('dirselect').selectedIndex].value;
			var timeslide_value=document.getElementById('timemarks').value;
			document.getElementById("themiddle").innerHTML = document.getElementById('timemarks').value + ":00";
			console.log(yearlist_value,daylist_value,dirlist_value,timeslide_value);
			getStationData(yearlist_value,daylist_value,dirlist_value,timeslide_value);
		});

		$("#btn-clear").click( function(event){
			event.preventDefault();
			//Clear Markers and remove event listener for map drag
			setAllMap(null);
			google.maps.event.clearListeners(map);
		});

		$("#btn-SKIP").click( function(event){
			event.preventDefault();
			document.getElementById("help1").style.visibility="hidden";
			//$("#station-details").fadeIn("slow");
		});

		$("#btn-NEXT").click( function(event){
			event.preventDefault();
			document.getElementById("help1").style.visibility="hidden";
			document.getElementById("help2text").style.visibility="visible";
		});

		$("#btn-NEXT2").click( function(event){
			event.preventDefault();
			document.getElementById("help2text").style.visibility="hidden";
			document.getElementById("help3text").style.visibility="visible";
		});

		$("#btn-NEXT3").click( function(event){
			event.preventDefault();
			document.getElementById("help3text").style.visibility="hidden";
			document.getElementById("help4text").style.visibility="visible";
		});

		$("#btn-NEXT4").click( function(event){
			event.preventDefault();
			document.getElementById("help4text").style.visibility="hidden";
			document.getElementById("help5text").style.visibility="visible";
		});

		$("#btn-NEXT5").click( function(event){
			event.preventDefault();
			document.getElementById("help5text").style.visibility="hidden";
			document.getElementById("help6text").style.visibility="visible";
		});

		$("#btn-COLSE6").click( function(event){
			event.preventDefault();
			document.getElementById("help6text").style.visibility="hidden";
		});

		$("#logo-year").click( function(event){
			event.preventDefault();
			document.getElementById("help2text").style.visibility="visible";
		});
		$("#help2text").click( function(event){
			event.preventDefault();
			document.getElementById("help2text").style.visibility="hidden";
		});

		$("#logo-dir").click( function(event){
			event.preventDefault();
			document.getElementById("help3text").style.visibility="visible";
		});
		$("#help3text").click( function(event){
			event.preventDefault();
			document.getElementById("help3text").style.visibility="hidden";
		});

		$("#logo-date").click( function(event){
			event.preventDefault();
			document.getElementById("help4text").style.visibility="visible";
		});
		$("#help4text").click( function(event){
			event.preventDefault();
			document.getElementById("help4text").style.visibility="hidden";
		});

		$("#logo-time").click( function(event){
			event.preventDefault();
			document.getElementById("help5text").style.visibility="visible";
		});
		$("#help5text").click( function(event){
			event.preventDefault();
			document.getElementById("help5text").style.visibility="hidden";
		});


		function initialize() {
			var mapOptions = {
				center: new google.maps.LatLng(51.514756, -0.104345),
				zoom: 12,
			 	styles: darkMap,
			 	disableDefaultUI: true,
			 	draggable: true
			};
			
			map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
			transitLayer.setMap(map);

			//getStationData($(".yearquery").attr("year_value"), $(".dayquery").attr("day_value"),
				//$(".dirquery").attr("dir_value"),$(".timequery").attr("time_value"));

			//getINflow(525,"MTT");
		}

		function getStationData(year, day,dir,time){
			console.log("Getting Data: " + year + day + dir + time );

			setAllMap(null);
			markerArray = [];

			var url = "http://dev.spatialdatacapture.org:8894/data/"+year+"/" + day +"/"+ dir +"/"+ time;

			console.log(url);
			console.log("Started ...");

			$.getJSON( url, function( data ) {
				$.each(data, function(k,v){
					
					var latLng = new google.maps.LatLng(v.lon, v.lat);
					
					dataArray.push(latLng);

					var scale = v.flow + 10;
					var colorindex=v.cluster
					var color  = HSLToRGB(0,0,100);
					var color2  = HSLToRGB(54,90,70);
					var color3  = HSLToRGB(230,60,50);

					var icon1 = {
                                    path: google.maps.SymbolPath.CIRCLE,
			                        scale: scale/600+3,
									//scale: 10,
                                    fillColor: color,
                                    fillOpacity: 0.9,
			                        strokeWeight: 0
                                 }
								 
                    var icon2 = {
                                    path: google.maps.SymbolPath.CIRCLE,
			                        scale: scale/600+3,
									//scale: 10,
                                    fillColor: color2,
                                    fillOpacity: 0.9,
			                        strokeWeight: 0
                                 }
                    var icon3 = {
                                    path: google.maps.SymbolPath.CIRCLE,
			                        scale: scale/600+3,
									//scale: 10,
                                    fillColor: color3,
                                    fillOpacity: 0.9,
			                        strokeWeight: 0
                                 }

                    if (v.cluster==1){
                    	var icon= icon1
                    }
                    else if (v.cluster==2){
                    	var icon= icon2
                    }
                    else {
                    	var icon= icon3
                    }

					var marker = new google.maps.Marker({
		     				  	position: latLng,
                                icon: icon
								//animation: google.maps.Animation.DROP
		     				  });

      				//console.log(marker)


					google.maps.event.addListener(marker, 'mouseover', function(content) {
						return function(){
							var content = "<b>Station Name: </b><br/>"+v.station+"<br/> <br/><b>Flow:</b>"+v.flow;
							infowindow.setContent(content);
							//map.setCenter(latLng);
						    infowindow.open(map,this);
						}
					}(""));

					google.maps.event.addListener(marker, 'click', function(content) {
						return function(){
							document.getElementById("station-details").style.visibility="visible";
							$("#station-details").fadeIn("slow");
							//infowindow.setContent(content);
							map.setCenter(latLng);
							getINflow(v.nlc,v.day);
							getOUTflow(v.nlc,v.day);
							var url2="http://dev.spatialdatacapture.org:8894/data/descrp/"+v.nlc +"/"+ v.day;
							console.log("The content replaced by"+url2)
							$.getJSON(url2,function(data2) {
										document.getElementById('text-name').textContent = v.station;
										document.getElementById('text-mode').textContent = data2[0]["mode"];
										document.getElementById('text-nlc').textContent = v.nlc;
										document.getElementById('text-asc').textContent = data2[0]["asc"];
										document.getElementById('datedescrp').innerHTML = v.day;
										document.getElementById('drop1').innerHTML = data2[0]["drop"];
										document.getElementById('drop2').innerHTML = data2[2]["drop"];
										if (data2[0]["cluster"]==data2[1]["cluster"]){
											document.getElementById('inside1').innerHTML = "remains unchanged";
										}
										else{
											document.getElementById('inside1').innerHTML = "changed from " +data2[0]["cluster_name"]+ " to " +data2[1]["cluster_name"];
										};
										if (data2[2]["cluster"]==data2[3]["cluster"]){
											document.getElementById('inside2').innerHTML = "remains unchanged";
										}
										else{
											document.getElementById('inside2').innerHTML = "changed from " +data2[2]["cluster_name"]+ " to " +data2[3]["cluster_name"];
										};
										console.log("Description changed already!")
									})
						    //infowindow.open(map,this);
						}
					}(""));

					markerArray.push(marker);

      			});
      			
      			setAllMap(map);
      			console.log("Done!")
			});
		}



		google.maps.event.addDomListener(window, 'load', initialize);

	});

	//  ******************* FUNCTIONS TO USE FOR THE MAP YOU DON"T NEED TO EDIT ANYTHING BELOW THIS LINE **************************************************
	
	function createMarkers(){
		var marker = new google.maps.Marker({
  			position: latLng 				
  		});
	}

	function setAllMap(map) {
		for (var i = 0; i < markerArray.length; i++) {
			markerArray[i].setMap(map);
		}
	}

	function clearMarkers() {
		setAllMarkers(null);
	}

	String.prototype.replaceAll = function(str1, str2, ignore) {
    	return decodeURIComponent( this.replace(new RegExp(str1.replace(/([\/\,\!\\\^\$\{\}\[\]\(\)\.\*\+\?\|\<\>\-\&])/g,"\\$&"),(ignore?"gi":"g")),(typeof(str2)=="string")?str2.replace(/\$/g,"$$$$"):str2) );
	} 

	$("#Modetitle").click(function(){
		$("#Modeselect").slideToggle("slow");
    });
	
	$('#help').click(function(){
		$('#helppic').fadeIn();
	});

	$('#helppic').click(function(){
		$('#helppic').fadeOut();
	});
	
	$('#close').click(function(event){
		event.preventDefault();
		document.getElementById("station-details").style.visibility="hidden";
	});

    function hidebar(){
		//document.getElementById("right").style.visibility="hidden";
		$("#station-details").fadeOut("slow");
		
	}

	var isHiden = false;
	$('#left3').click(function(){
		var lr = document.getElementById("lr");
	    if(isHiden){
	        $('#left').animate({left:'+=659px'},800);
			lr.setAttribute("src","img/right.png");
	    }else{
	        $('#left').animate({left:'-=659px'},800);
			lr.setAttribute("src","img/right.png");
	    }
	    isHiden = !isHiden;
	});

	function HSLToRGB(h,s,l) {
		// Must be fractions of 1
		s = Math.round(s);
		s /= 100;
		l /= 100;

		let c = (1 - Math.abs(2 * l - 1)) * s,
		x = c * (1 - Math.abs((h / 60) % 2 - 1)),
		m = l - c/2,
		r = 0,
		g = 0,
		b = 0;
		if (0 <= h && h < 60) {
			r = c; g = x; b = 0;
		} else if (60 <= h && h < 120) {
			r = x; g = c; b = 0;
		} else if (120 <= h && h < 180) {
			r = 0; g = c; b = x;
		} else if (180 <= h && h < 240) {
			r = 0; g = x; b = c;
		} else if (240 <= h && h < 300) {
			r = x; g = 0; b = c;
		} else if (300 <= h && h < 360) {
			r = c; g = 0; b = x;
		}
		r = Math.round((r + m) * 255);
		g = Math.round((g + m) * 255);
		b = Math.round((b + m) * 255);

		return "rgb(" + r + "," + g + "," + b + ")";
	}
